package AdmissionSystem;

public class Application {
}
